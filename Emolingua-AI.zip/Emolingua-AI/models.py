import streamlit as st
import streamlit.components.v1 as components
from sgmker_bert import query_bert
import time
import pyttsx3

def getSentiments(userText, type):
    if type == 'EMOLINGUA-BERT':
        return query_bert({"inputs": userText})
    else:
        return {"Positive": 0.0, "Neutral": 0.0, "Negative": 0.0}

def renderPage():
    st.title("Emolingua AI Model Playground😊")
    st.text("")
    type = st.selectbox(
        "$$\large\\text{Select a model}$$",
        ('EMOLINGUA-BERT', 'EMOLINGUA-GEMMA'))
    
    st.text("")

    # Custom HTML for the input field with a microphone
    components.html("""
        <div style="display: flex; align-items: center;">
            <input type="text" id="userText" placeholder="Just say it" style="width: 80%; padding: 10px; font-size: 16px; flex-grow: 1;">
            <button onclick="startDictation()" style="padding: 10px; margin-left: 10px;">
                <img src="https://img.icons8.com/ios-filled/50/000000/microphone.png" style="width: 24px; height: 24px;">
            </button>
        </div>
        <script>
            function startDictation() {
                if (window.hasOwnProperty('webkitSpeechRecognition')) {
                    var recognition = new webkitSpeechRecognition();

                    recognition.continuous = false;
                    recognition.interimResults = false;

                    recognition.lang = "en-US";
                    recognition.start();

                    recognition.onresult = function(e) {
                        document.getElementById('userText').value = e.results[0][0].transcript;
                        recognition.stop();
                        // Trigger change event to update the session state in Streamlit
                        var event = new Event('input', { bubbles: true });
                        document.getElementById('userText').dispatchEvent(event);
                    };

                    recognition.onerror = function(e) {
                        recognition.stop();
                    };
                }
            }
        </script>
    """, height=100)

    # Hidden text input to capture the value from the HTML input field
    userText = st.text_input( "$$\large\\text{Model Input}$$", value="", key="userText_input", placeholder="Enter a statement")

    if st.session_state.get("userText_input"):
        userText = st.session_state["userText_input"]

    var = st.button('Predict')

    if type == 'EMOLINGUA-BERT':
        with st.container():
            st.title("Results")
            st.text("")
            my_bar = st.progress(0)
            my_bar2 = st.progress(0)
            my_bar3 = st.progress(0)

            if var and userText:
                st.write(f"Input text: {userText}")  # Debug: Show input text
                result = getSentiments(userText, type)
                st.write(f"Model response: {result}")  # Debug: Show model response
                pos, neu, neg = round(result['Positive'], 4), round(result['Neutral'], 4), round(result['Negative'], 4)
                
                max_sentiment = max(pos, neu, neg)
                if max_sentiment == pos:
                    sentiment_str = "Positive"
                elif max_sentiment == neu:
                    sentiment_str = "Neutral"
                else:
                    sentiment_str = "Negative"
                
                engine = pyttsx3.init()
                engine.say(f"The most dominant sentiment is {sentiment_str}")
                engine.runAndWait()

                for percent_complete in range(0, int(pos*100)+1):
                    time.sleep(0.01)
                    my_bar.progress(percent_complete, text=f"$$\large\\text{{Positive}} : {pos}$$")

                for percent_complete in range(0, int(neu*100)+1):
                    time.sleep(0.01)
                    my_bar2.progress(percent_complete, text=f"$$\large\\text{{Neutral}} : {neu}$$")

                for percent_complete in range(0, int(neg*100)+1):
                    time.sleep(0.01)
                    my_bar3.progress(percent_complete, text=f"$$\large\\text{{Negative}} : {neg}$$")

    elif type == 'EMOLINGUA-GEMMA':
        with st.container():
            if var and userText:
                gemma_response = getSentiments(userText, type)
                st.header("Model Response:")
                components.html(f"""
                    <h3 style="color: #ffffff; font-family: Source Sans Pro, sans-serif; font-size: 28px;">{gemma_response}</h3>
                """, height=300)

if __name__ == "__main__":
    renderPage()
