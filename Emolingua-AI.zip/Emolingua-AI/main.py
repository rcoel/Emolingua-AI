import streamlit as st
import sidebar
import models

def about_us():
    st.title("🌟 About Us 🌟")

    st.markdown("""
        Emolingua AI is a team of passionate individuals dedicated to advancing 
        natural language processing and sentiment analysis technologies. Our mission
        is to empower users with intuitive AI tools that enhance communication and 
        understanding in the digital world.
    """)
    
    st.write("🚀 Meet the Team:")
    st.write("👩‍💻 **_Edita Fernandes_**: Worked on GEMMA model, data collection, and frontend")
    st.write("👩‍💻 **_Jane Dsa_**: Worked on data collection, BERT model, and visualization")
    st.write("👨‍💻 **_Nithyananda Shetty_**: Worked on BERT model, linguistic analysis, and frontend")
    st.write("👨‍💻 **_Reevan Coelho_**: Worked on GEMMA model, API integration, and feature engineering")


page = sidebar.show()

if page == 'Playground':
    models.renderPage()
elif page == 'Home':
    st.title("🌟 Welcome to Emolingua 🚀")

    st.markdown("---")

    # Main content section with sleek layout and refined typography
    st.write("Emolingua is your go-to tool for identifying the sentiment of transliterated Kannada text.")
    st.write("Here's what you can do with Emolingua:")
    st.write("- 📚 **Analyze the sentiment of your Kannada text.**")  # Making the text bold
    st.write("- 🔄 **Experiment with different transliteration styles.**")  # Making the text bold
    st.write("- 📊 **Visualize sentiment analysis results.**")  # Making the text bold
    st.write("- 📈 **Track sentiment trends over time.**")  # Making the text bold

    st.markdown("---")

    # Add an interactive button with a modern design
    if st.button("**Get Started 🚀**", key="get_started_button"):  # Making the button text bold
        st.write("Let's explore the sentiment of your Kannada text!")




elif page == 'AboutUs':
    about_us()
